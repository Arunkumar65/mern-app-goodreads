import React from 'react'
import { Container } from 'react-bootstrap'

export const ProfileDetails = () => {
  return (
    <Container
      
    />
  )
}
