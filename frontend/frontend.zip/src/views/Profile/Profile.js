import React from 'react'
import { ProfileDetails } from '../../component/Profile/ProfileDetails'

export const Profile = () => {
  return (
    <div>
      <ProfileDetails />
    </div>
  )
}
